Luke Austin La'akea Passmore
lpassmore3@gatech.edu
Java Version: Java 1.8.0_101

I did not do any extra credit.
I planned on making the application look a lot more
aesthetically pleasing, but was running out of time.
I will try to make it look nicer for future assignments.